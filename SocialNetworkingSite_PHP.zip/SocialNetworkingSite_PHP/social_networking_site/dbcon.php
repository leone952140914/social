	<?php $conn = new PDO('mysql:host=localhost;dbname=socialdb', 'root', ''); ?>
